import UIKit

var ogrenciAdi = "Büşra"
var ogrenciYas = 28
var ogrenciBoy = 1.69
var ogrenciBasHarf = "B"
var ogrenciDevamEdiyorMu = true

print (ogrenciAdi)
print (ogrenciYas)
print (ogrenciBoy)
print (ogrenciBasHarf)
print (ogrenciDevamEdiyorMu)
